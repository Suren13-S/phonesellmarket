// Բնութագրերի կոճակների համար

const detailButtons = document.querySelectorAll('.details-btn');

detailButtons.forEach(button => {

  button.addEventListener('click', () => {

    const specs = button.nextElementSibling;

    if (specs.style.display === 'none' || specs.style.display === '') {

      specs.style.display = 'block';

      button.textContent = 'Փակել բնութագիրը';

    } else {

      specs.style.display = 'none';

      button.textContent = 'Տեսնել բնութագիրը';

    }

  });

});